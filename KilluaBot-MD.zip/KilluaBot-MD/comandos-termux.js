
*PRIMEIRO, BAIXE A TERMUX NA PLAY STORE!*

1. termux-setup-storage


2. cd /sdcard && git clone https://github.com/bielzin998/KilluaBot-MD


3. cd /sdcard/KilluaBot-MD && npm start 


4. Após isso, é só escanear o QR code com um segundo celular e pronto!